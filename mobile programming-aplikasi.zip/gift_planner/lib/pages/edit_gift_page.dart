import 'package:flutter/material.dart';

class EditGiftPage extends StatelessWidget {
  const EditGiftPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Edit Gift")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(decoration: InputDecoration(labelText: "Gift Name")),
            TextField(decoration: InputDecoration(labelText: "Category")),
            TextField(decoration: InputDecoration(labelText: "Price Range")),
            SizedBox(height: 20),
            ElevatedButton(onPressed: () {}, child: Text("Save")),
          ],
        ),
      ),
    );
  }
}
