import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';

class ReminderPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Reminders")),
      bottomNavigationBar: MyBottomNav(currentIndex: 2),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Card(child: ListTile(
            leading: Icon(Icons.cake, color: Colors.pink),
            title: Text("Birthday"),
            subtitle: Text("Reminder ON"),
          )),
        ],
      ),
    );
  }
}
