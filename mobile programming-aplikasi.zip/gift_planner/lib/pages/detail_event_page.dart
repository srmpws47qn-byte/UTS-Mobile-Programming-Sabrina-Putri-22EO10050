import 'package:flutter/material.dart';
import 'edit_event_page.dart';
import 'edit_gift_page.dart';

class DetailEventPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Detail Event"),
      ),

      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [

            // ---------- EVENT INFORMATION CARD ----------
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 3,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Row(
                  children: [
                    Icon(Icons.cake, color: Colors.pink, size: 40),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Birthday", 
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                          SizedBox(height: 6),
                          Text("Date: 14 February 2025"),
                          Text("Time: 08:00 AM"),
                          Row(
                            children: [
                              Icon(Icons.alarm, color: Colors.pink),
                              SizedBox(width: 6),
                              Text("Reminder: ON"),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 18),

            // ---------- GIFT INFORMATION CARD ----------
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 3,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Gift Information", 
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    SizedBox(height: 12),

                    Text("Gift Name: Chocolate Box"),
                    Text("Category: Food"),
                    Text("Price Range: 50K - 100K"),
                    SizedBox(height: 10),
                    Text("Notes: Sweet chocolate with premium packaging"),

                    SizedBox(height: 14),

                    Align(
                      alignment: Alignment.centerRight,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(context,
                            MaterialPageRoute(builder: (_) => EditGiftPage()));
                        },
                        child: Text("Edit Gift"),
                      ),
                    )
                  ],
                ),
              ),
            ),

            SizedBox(height: 18),

            // ---------- EVENT NOTES / BUDGET ----------
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 3,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Event Notes", 
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    SizedBox(height: 10),

                    Text("Budget: 150,000 IDR"),
                    SizedBox(height: 6),

                    Text("Notes: Prepare a handwritten birthday card."),
                  ],
                ),
              ),
            ),

            SizedBox(height: 30),

            // ---------- BUTTONS ----------
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
              onPressed: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (_) => EditEventPage()));
              },
              child: Text("Edit Event"),
            ),

            SizedBox(height: 12),

            OutlinedButton(
              onPressed: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (_) => EditGiftPage()));
              },
              child: Text("Edit Gift"),
            ),
          ],
        ),
      ),
    );
  }
}
