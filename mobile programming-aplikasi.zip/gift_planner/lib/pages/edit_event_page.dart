import 'package:flutter/material.dart';

class EditEventPage extends StatelessWidget {
  const EditEventPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Edit Event")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(decoration: InputDecoration(labelText: "Event Name")),
            TextField(decoration: InputDecoration(labelText: "Date")),
            TextField(decoration: InputDecoration(labelText: "Notes")),
            SizedBox(height: 20),
            ElevatedButton(onPressed: () {}, child: Text("Save")),
          ],
        ),
      ),
    );
  }
}
