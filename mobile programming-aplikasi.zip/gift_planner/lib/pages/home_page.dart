import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Upcoming Events")),
      bottomNavigationBar: MyBottomNav(currentIndex: 0),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          eventCard("Birthday", "1 January 2025", Icons.cake),
          eventCard("Anniversary", "14 March 2025", Icons.favorite),
          eventCard("Wedding", "30 June 2025", Icons.church),
        ],
      ),
    );
  }

  Widget eventCard(String title, String date, IconData icon) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: Colors.pink),
        title: Text(title),
        subtitle: Text(date),
        trailing: Icon(Icons.arrow_forward_ios),
      ),
    );
  }
}
