import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';

class AddEventPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Event")),
      bottomNavigationBar: MyBottomNav(currentIndex: 1),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(decoration: InputDecoration(labelText: "Event Name")),
              TextField(decoration: InputDecoration(labelText: "Date")),
              TextField(decoration: InputDecoration(labelText: "Category")),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {},
                child: Text("Save"),
              )
            ],
          ),
        ),
      ),
    );
  }
}
