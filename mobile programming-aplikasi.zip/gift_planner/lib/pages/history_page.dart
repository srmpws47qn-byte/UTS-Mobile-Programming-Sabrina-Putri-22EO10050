import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';

class HistoryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Event History")),
      bottomNavigationBar: MyBottomNav(currentIndex: 3),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Card(child: ListTile(
            leading: Icon(Icons.favorite, color: Colors.pink),
            title: Text("Valentine's Day"),
            subtitle: Text("Completed"),
          )),
        ],
      ),
    );
  }
}
