import 'package:flutter/material.dart';
import '../pages/home_page.dart';
import '../pages/add_event_page.dart';
import '../pages/reminder_page.dart';
import '../pages/history_page.dart';

class MyBottomNav extends StatelessWidget {
  final int currentIndex;

  MyBottomNav({required this.currentIndex});

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      selectedItemColor: Colors.pink,
      onTap: (i) {
        if (i == 0) Navigator.push(context, MaterialPageRoute(builder: (_) => HomePage()));
        if (i == 1) Navigator.push(context, MaterialPageRoute(builder: (_) => AddEventPage()));
        if (i == 2) Navigator.push(context, MaterialPageRoute(builder: (_) => ReminderPage()));
        if (i == 3) Navigator.push(context, MaterialPageRoute(builder: (_) => HistoryPage()));
      },
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.add), label: "Add Event"),
        BottomNavigationBarItem(icon: Icon(Icons.notifications), label: "Reminder"),
        BottomNavigationBarItem(icon: Icon(Icons.history), label: "History"),
      ],
    );
  }
}
