import 'package:flutter/material.dart';

// Import semua halaman yang sudah dibuat
import 'pages/splash_screen.dart';
import 'pages/home_page.dart';
import 'pages/add_event_page.dart';
import 'pages/reminder_page.dart';
import 'pages/history_page.dart';
import 'pages/detail_event_page.dart';
import 'pages/edit_event_page.dart';
import 'pages/edit_gift_page.dart';

void main() {
  runApp(MyGiftPlanner());
}

class MyGiftPlanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "My Gift Planner",

      theme: ThemeData(
        primarySwatch: Colors.pink,
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.pink,
          foregroundColor: Colors.white,
          elevation: 2,
        ),
      ),

      // Halaman pertama yang dijalankan
      home: SplashScreen(),

      // Routing opsional (tidak wajib, tetapi mempermudah navigasi)
      routes: {
        "/home": (context) => HomePage(),
        "/addEvent": (context) => AddEventPage(),
        "/reminder": (context) => ReminderPage(),
        "/history": (context) => HistoryPage(),
        "/detail": (context) => DetailEventPage(),
        "/editEvent": (context) => EditEventPage(),
        "/editGift": (context) => EditGiftPage(),
      },
    );
  }
}
