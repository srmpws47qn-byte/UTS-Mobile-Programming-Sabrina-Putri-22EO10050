package com.example.gift_planner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
